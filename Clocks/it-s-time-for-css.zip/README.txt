A Pen created at CodePen.io. You can find this one at https://codepen.io/ebrewe/pen/gxobvQ.

 showing a backend dev colleague how quick n' easy it is to build a css clock.