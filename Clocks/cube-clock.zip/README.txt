A Pen created at CodePen.io. You can find this one at http://codepen.io/stix/pen/mVXypr.

 