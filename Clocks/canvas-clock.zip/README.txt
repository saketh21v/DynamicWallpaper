A Pen created at CodePen.io. You can find this one at http://codepen.io/Maku2202/pen/MarRgK.

 A clock made whith canvas javascript.
Looks like a Hacker

The code were based on this tutorial (isn't mine)
https://www.youtube.com/watch?v=9dtDaWi6R0g 